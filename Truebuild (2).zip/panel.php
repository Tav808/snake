<?php
session_start();

if (!isset($_SESSION['usuario_logueado'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mi Cuenta — TrueBuild PC</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800;900&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
--navy:#0a1628;
--navy2:#0f1f38;
--navy3:#162844;
--blue:#1d5fa8;
--blue2:#2e7dd4;
--white:#fff;
--border:rgba(255,255,255,.08);
}
body{
font-family:'Barlow',sans-serif;
background:linear-gradient(180deg,var(--navy),#08111f);
color:var(--white);
min-height:100vh;
}
nav{
height:72px;
display:flex;
align-items:center;
justify-content:space-between;
padding:0 4rem;
background:rgba(10,22,40,.95);
border-bottom:1px solid var(--border);
backdrop-filter:blur(12px);
}
.logo{
font-family:'Barlow Condensed',sans-serif;
font-size:1.6rem;
font-weight:900;
text-decoration:none;
color:white;
text-transform:uppercase;
}
.logo span{color:var(--blue2)}
.nav-actions{display:flex;gap:1rem}
.btn{
text-decoration:none;
padding:.8rem 1.4rem;
border-radius:6px;
font-weight:700;
text-transform:uppercase;
letter-spacing:.08em;
font-size:.85rem;
transition:.2s;
}
.btn-home{background:var(--blue);color:white}
.btn-home:hover{background:var(--blue2)}
.btn-logout{border:1px solid rgba(255,255,255,.15);color:rgba(255,255,255,.8)}
.btn-logout:hover{background:rgba(255,255,255,.08)}
.hero{
max-width:1200px;
margin:auto;
padding:5rem 2rem;
display:grid;
grid-template-columns:1.2fr .8fr;
gap:2rem;
align-items:center;
}
.card{
background:var(--navy2);
border:1px solid var(--border);
border-radius:18px;
padding:2.5rem;
box-shadow:0 20px 60px rgba(0,0,0,.35);
}
.eyebrow{
color:#4a9eff;
font-size:.8rem;
font-weight:700;
letter-spacing:.2em;
text-transform:uppercase;
margin-bottom:1rem;
}
h1{
font-family:'Barlow Condensed',sans-serif;
font-size:4rem;
line-height:.95;
text-transform:uppercase;
margin-bottom:1rem;
}
h1 span{color:var(--blue2)}
.desc{
color:rgba(255,255,255,.65);
font-size:1.05rem;
max-width:600px;
margin-bottom:2rem;
}
.stats{
display:grid;
grid-template-columns:repeat(2,1fr);
gap:1rem;
margin-top:2rem;
}
.stat{
background:rgba(255,255,255,.03);
padding:1rem;
border-radius:10px;
border:1px solid rgba(255,255,255,.06);
}
.stat-label{
font-size:.75rem;
text-transform:uppercase;
letter-spacing:.12em;
color:rgba(255,255,255,.45);
margin-bottom:.4rem;
}
.stat-value{font-weight:600;font-size:1rem}
.side-panel{
height:100%;
display:flex;
flex-direction:column;
justify-content:center;
background:linear-gradient(145deg,var(--navy3),var(--navy2));
}
.badge{
background:rgba(46,125,212,.15);
border:1px solid rgba(46,125,212,.35);
padding:.9rem 1rem;
border-radius:10px;
margin-bottom:1rem;
}
.badge strong{display:block;margin-bottom:.3rem}
@media(max-width:900px){
nav{padding:0 1.5rem}
.hero{grid-template-columns:1fr}
h1{font-size:2.8rem}
}
</style>
</head>
<body>
<nav>
<a href="truebuild.html" class="logo">TRUE<span>BUILD</span></a>
<div class="nav-actions">
<a href="truebuild.html" class="btn btn-home">Volver al inicio</a>
<a href="login.php?salir=true" class="btn btn-logout">Cerrar sesión</a>
</div>
</nav>

<section class="hero">
<div class="card">
<div class="eyebrow">Sesión iniciada correctamente</div>
<h1>Hola, <span><?php echo htmlspecialchars($_SESSION['usuario_logueado']); ?></span></h1>
<p class="desc">
Tu cuenta de TrueBuild ya está activa. Desde acá podés volver a la página principal y seguir explorando builds, componentes y servicios.
</p>

<a href="truebuild.html" class="btn btn-home">Ir a TrueBuild</a>

<div class="stats">
<div class="stat">
<div class="stat-label">Correo</div>
<div class="stat-value"><?php echo htmlspecialchars($_SESSION['usuario_email']); ?></div>
</div>
<div class="stat">
<div class="stat-label">ID de usuario</div>
<div class="stat-value">#<?php echo $_SESSION['usuario_id']; ?></div>
</div>
</div>
</div>

<div class="card side-panel">
<div class="badge">
<strong>Diseño renovado</strong>
El panel ahora mantiene la misma estética moderna del sitio principal.
</div>
<div class="badge">
<strong>Navegación rápida</strong>
Podés volver al inicio en cualquier momento desde la barra superior.
</div>
<div class="badge">
<strong>Experiencia integrada</strong>
Después del login el usuario vuelve automáticamente a la experiencia principal de TrueBuild.
</div>
</div>
</section>
</body>
</html>
