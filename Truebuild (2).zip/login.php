<?php
session_start();
include 'conexion.php';

$respuesta = array('exito' => false, 'mensaje' => '');

// FUNCIÓN DE LOGIN
if ($_POST && isset($_POST['accion']) && $_POST['accion'] == 'login') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    // Validar campos
    if (empty($email) || empty($password)) {
        $respuesta['mensaje'] = 'Email y contraseña son requeridos.';
    } else {
        // Usar prepared statement para evitar SQL injection
        $stmt = $conexion->prepare("SELECT id_Usuario, nombreU, emailU FROM usuarios WHERE emailU = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows > 0) {
            $usuario = $resultado->fetch_assoc();
            // Verificar contraseña (usar password_verify si usas hash)
            $stmt_pass = $conexion->prepare("SELECT contraseñaU FROM usuarios WHERE emailU = ? AND contraseñaU = ?");
            $stmt_pass->bind_param("ss", $email, $password);
            $stmt_pass->execute();
            $resultado_pass = $stmt_pass->get_result();
            
            if ($resultado_pass->num_rows > 0) {
                // Login exitoso
                $_SESSION['usuario_logueado'] = $usuario['nombreU'];
                $_SESSION['usuario_email'] = $usuario['emailU'];
                $_SESSION['usuario_id'] = $usuario['id_Usuario'];
                $respuesta['exito'] = true;
                $respuesta['mensaje'] = 'Login exitoso';
            } else {
                $respuesta['mensaje'] = 'Contraseña incorrecta.';
            }
            $stmt_pass->close();
        } else {
            $respuesta['mensaje'] = 'El email no está registrado.';
        }
        $stmt->close();
    }
    
    // Retornar JSON
    header('Content-Type: application/json');
    echo json_encode($respuesta);
    exit();
}

// FUNCIÓN DE REGISTRO
if ($_POST && isset($_POST['accion']) && $_POST['accion'] == 'registro') {
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];
    
    // Validar campos
    if (empty($nombre) || empty($apellido) || empty($email) || empty($password) || empty($confirm)) {
        $respuesta['mensaje'] = 'Todos los campos son requeridos.';
    } elseif ($password !== $confirm) {
        $respuesta['mensaje'] = 'Las contraseñas no coinciden.';
    } elseif (strlen($password) < 6) {
        $respuesta['mensaje'] = 'La contraseña debe tener mínimo 6 caracteres.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $respuesta['mensaje'] = 'Email inválido.';
    } else {
        // Verificar si el email ya existe
        $stmt = $conexion->prepare("SELECT id_Usuario FROM usuarios WHERE emailU = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows > 0) {
            $respuesta['mensaje'] = 'El email ya está registrado.';
        } else {
            // Crear el usuario
            // IMPORTANTE: En producción, usa password_hash() para mayor seguridad
            $stmt_insert = $conexion->prepare("INSERT INTO usuarios (nombreU, contraseñaU, emailU) VALUES (?, ?, ?)");
            $stmt_insert->bind_param("sss", $nombre, $password, $email);
            
            if ($stmt_insert->execute()) {
                $respuesta['exito'] = true;
                $respuesta['mensaje'] = 'Registro exitoso. Ahora puedes iniciar sesión.';
            } else {
                $respuesta['mensaje'] = 'Error al registrar: ' . $conexion->error;
            }
            $stmt_insert->close();
        }
        $stmt->close();
    }
    
    // Retornar JSON
    header('Content-Type: application/json');
    echo json_encode($respuesta);
    exit();
}

// FUNCIÓN DE LOGOUT
if (isset($_GET['salir'])) {
    session_destroy();
    header("Location: login.html");
    exit();
}

// Si ya está logueado, redirigir a panel
if (isset($_SESSION['usuario_logueado'])) {
    header("Location: panel.php");
    exit();
}
?>
