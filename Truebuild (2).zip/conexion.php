<?php
$conexion = new mysqli("localhost", "root", "", "truebuild");

// Verificar conexión
if ($conexion->connect_error) {
    die("Error conectando a la base de datos: " . $conexion->connect_error);
}

// Configurar charset a utf8mb4
$conexion->set_charset("utf8mb4");
?>
